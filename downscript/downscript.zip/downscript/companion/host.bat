@echo off
rem Chrome starts this file on Windows; it runs host.py with the companion venv.
"%~dp0.venv\Scripts\python.exe" "%~dp0host.py"
