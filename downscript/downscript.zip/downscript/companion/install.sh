#!/usr/bin/env bash
#
# Registers the Downscript native messaging host with Chrome so the extension
# can talk to host.py. Run this once after loading the unpacked extension.
#
# Usage:
#   ./install.sh                  # uses the default baked-in extension ID
#   ./install.sh <EXTENSION_ID>   # override (e.g. if you repacked with a new key)
#
set -euo pipefail

# Extension ID derived from the public key in extension/manifest.json.
# (sha256 of the DER public key, first 16 bytes, mapped to a-p.)
DEFAULT_EXTENSION_ID="hkmbgalpmjbphbjbldhghodghfmcbafi"
EXTENSION_ID="${1:-$DEFAULT_EXTENSION_ID}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOST_PATH="$SCRIPT_DIR/host.py"
TEMPLATE="$SCRIPT_DIR/com.downscript.companion.json.template"

# macOS Chrome native messaging host directory.
NMH_DIR="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
MANIFEST_PATH="$NMH_DIR/com.downscript.companion.json"

if [[ ! -f "$HOST_PATH" ]]; then
  echo "ERROR: host.py not found at $HOST_PATH" >&2
  exit 1
fi

# Verify python3 is available (host.py's shebang relies on it).
if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 not found on PATH. Install Python 3 first." >&2
  exit 1
fi

chmod +x "$HOST_PATH"

mkdir -p "$NMH_DIR"

# Fill the template with absolute host path + extension ID.
sed -e "s|__HOST_PATH__|$HOST_PATH|g" \
    -e "s|__EXTENSION_ID__|$EXTENSION_ID|g" \
    "$TEMPLATE" > "$MANIFEST_PATH"

echo "Installed native messaging host:"
echo "  manifest:  $MANIFEST_PATH"
echo "  host:      $HOST_PATH"
echo "  extension: chrome-extension://$EXTENSION_ID/"
echo
echo "Next steps:"
echo "  1. Load the unpacked extension from:"
echo "       $(cd "$SCRIPT_DIR/../extension" && pwd)"
echo "  2. Confirm the extension ID in chrome://extensions matches:"
echo "       $EXTENSION_ID"
echo "     If it differs, re-run: ./install.sh <the-id-chrome-shows>"
echo "  3. Open the extension's Settings and click 'Check setup'."
echo
echo "Note (macOS): yt-dlp reads browser cookies from the OS keychain/cookie"
echo "store. If downloads fail with a permissions error, grant your terminal"
echo "(or Chrome) Full Disk Access in System Settings > Privacy & Security."
