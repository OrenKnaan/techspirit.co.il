#!/usr/bin/env python3
"""Downscript native messaging host.

Speaks Chrome's native messaging protocol over stdin/stdout (4-byte
little-endian length prefix + UTF-8 JSON), and drives pipeline.py to turn
batches of video items into transcript files.

Message types received from the extension:
  - {"type": "ping", "settings": {...}}
  - {"type": "extract_batch", "runKey", "platform", "accountTitle",
     "outputDir", "settings", "items": [...]}
  - {"type": "open_folder", "path": "..."}
  - {"type": "open_debug_log", "path": "..."}
  - {"type": "read_debug_log", "path": "..."}

Messages sent back:
  - {"type": "pong", "ok": bool, "checks": [...]}
  - {"type": "item_done", "runKey", "id", "status", "code", "reason"}
  - {"type": "item_progress", "runKey", "id", "phase"}
  - {"type": "rate_limited", "runKey"}
  - {"type": "debug_log_content", "content": "..."}
"""

import json
import os
import signal
import struct
import subprocess
import sys
import time
import traceback

# Make sibling pipeline.py importable regardless of cwd Chrome launches us in.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pipeline  # noqa: E402


def _handle_terminate(signum, frame):
    # Chrome sends this when the extension disconnects the native port
    # (Cancel, or the popup closing mid-extraction). Python's default
    # SIGTERM handling would just kill this process and orphan whatever
    # subprocess extract_one is blocked on, so kill it explicitly first.
    pipeline.kill_current_proc()
    sys.exit(0)


signal.signal(signal.SIGTERM, _handle_terminate)


if os.name == "nt":
    # Native messaging is a binary protocol; stop Windows translating newlines.
    import msvcrt
    msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
    msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)


def open_path(path):
    """Open a file or folder with the OS default handler."""
    if os.name == "nt":
        os.startfile(str(path))  # noqa: S606
    elif sys.platform == "darwin":
        subprocess.run(["open", str(path)], check=False)
    else:
        subprocess.run(["xdg-open", str(path)], check=False)


def read_message():
    raw_len = sys.stdin.buffer.read(4)
    if len(raw_len) < 4:
        return None  # stdin closed -> Chrome disconnected
    msg_len = struct.unpack("<I", raw_len)[0]
    data = sys.stdin.buffer.read(msg_len)
    return json.loads(data.decode("utf-8"))


def send_message(obj):
    data = json.dumps(obj).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("<I", len(data)))
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def handle_ping(msg):
    settings = msg.get("settings", {})
    checks = pipeline.check_setup(settings)
    ok = all(c["ok"] for c in checks)
    send_message({"type": "pong", "ok": ok, "checks": checks})


def handle_extract_batch(msg):
    run_key = msg.get("runKey")
    platform = msg.get("platform")
    account_title = msg.get("accountTitle", "")
    output_dir = msg.get("outputDir")
    settings = msg.get("settings", {})
    items = msg.get("items", [])

    # Session-level backoff detection: if too many consecutive items fail with
    # a network-shaped error, stop and report rate limiting rather than burning
    # through the whole queue. See TECHNICAL_DESIGN.md §7.
    consecutive_fail = 0
    RATE_LIMIT_THRESHOLD = 5

    # Pacing: space out actual downloads so we don't hammer TikTok back-to-back
    # (this is what was tripping the rate-limit detection above). 3 downloads
    # back-to-back, then a fixed pause, repeat.
    PAUSE_EVERY = 3
    PAUSE_SECONDS = 5
    downloaded_count = 0

    for i, item in enumerate(items):
        try:
            result = pipeline.extract_one(
                platform, item, settings, output_dir, account_title,
                progress_cb=lambda phase, _id=item["id"]: send_message({
                    "type": "item_progress",
                    "runKey": run_key,
                    "id": _id,
                    "phase": phase,
                }),
            )
        except Exception as e:  # noqa: BLE001
            result = {
                "status": "failed",
                "code": "E_UNEXPECTED",
                "reason": f"unexpected: {e}",
                "path": None,
            }

        send_message({
            "type": "item_done",
            "runKey": run_key,
            "id": item["id"],
            "status": result["status"],
            "code": result.get("code"),
            "reason": result.get("reason"),
        })

        if result["status"] == "failed":
            consecutive_fail += 1
            if consecutive_fail >= RATE_LIMIT_THRESHOLD:
                send_message({"type": "rate_limited", "runKey": run_key})
                return
        else:
            consecutive_fail = 0

        # Skipped items made no network request, so they don't count toward
        # pacing and don't need a delay before the next one.
        if result["status"] != "skipped" and i < len(items) - 1:
            downloaded_count += 1
            if downloaded_count % PAUSE_EVERY == 0:
                time.sleep(PAUSE_SECONDS)


def handle_open_folder(msg):
    path = pipeline.expand(msg.get("path", ""))
    if path.exists():
        open_path(path)


def handle_open_debug_log(msg):
    path = pipeline.debug_log_path(msg.get("path", ""))
    if path.exists():
        open_path(path)


def handle_read_debug_log(msg):
    content = pipeline.read_debug_log(msg.get("path", ""))
    send_message({"type": "debug_log_content", "content": content})


def main():
    while True:
        try:
            msg = read_message()
        except Exception:
            break
        if msg is None:
            break

        try:
            mtype = msg.get("type")
            if mtype == "ping":
                handle_ping(msg)
            elif mtype == "extract_batch":
                handle_extract_batch(msg)
            elif mtype == "open_folder":
                handle_open_folder(msg)
            elif mtype == "open_debug_log":
                handle_open_debug_log(msg)
            elif mtype == "read_debug_log":
                handle_read_debug_log(msg)
        except Exception as e:  # noqa: BLE001
            send_message({
                "type": "host_error",
                "error": str(e),
                "trace": traceback.format_exc()[-500:],
            })


if __name__ == "__main__":
    main()
