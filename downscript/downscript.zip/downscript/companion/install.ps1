# Registers the Downscript native messaging host with Chrome on Windows so the
# extension can talk to host.py. Run once after loading the unpacked extension.
#
# Usage (from the companion folder):
#   powershell -ExecutionPolicy Bypass -File .\install.ps1
#   powershell -ExecutionPolicy Bypass -File .\install.ps1 -ExtensionId <id>
param([string]$ExtensionId = "hkmbgalpmjbphbjbldhghodghfmcbafi")

$ErrorActionPreference = "Stop"
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$hostBat = Join-Path $dir "host.bat"
$venvPython = Join-Path $dir ".venv\Scripts\python.exe"
$template = Join-Path $dir "com.downscript.companion.json.template"
$manifestPath = Join-Path $dir "com.downscript.companion.json"

if (-not (Test-Path $hostBat)) { throw "host.bat not found at $hostBat" }
if (-not (Test-Path $venvPython)) {
    throw "The companion's .venv is missing. From this folder run: py -3 -m venv .venv ; .venv\Scripts\pip install -r requirements.txt"
}

# Fill the template with the absolute host path (backslashes escaped for JSON) and the extension ID.
$json = (Get-Content $template -Raw).Replace("__HOST_PATH__", $hostBat.Replace("\", "\\")).Replace("__EXTENSION_ID__", $ExtensionId)
[System.IO.File]::WriteAllText($manifestPath, $json, (New-Object System.Text.UTF8Encoding $false))

# Chrome finds native hosts through the registry on Windows. The default value points at the manifest.
$key = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.downscript.companion"
New-Item -Path $key -Value $manifestPath -Force | Out-Null

Write-Host "Installed native messaging host:"
Write-Host "  manifest:  $manifestPath"
Write-Host "  host:      $hostBat"
Write-Host "  extension: chrome-extension://$ExtensionId/"
Write-Host ""
Write-Host "Next: confirm the extension ID in chrome://extensions matches the one above,"
Write-Host "then open the extension's Settings and click 'Check setup'."
