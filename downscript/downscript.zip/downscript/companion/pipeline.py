"""Transcript extraction pipeline.

Generalized from EdwardStrum/scripts/extract_instagram.py. Turns a single
video item (id + permalink + optional caption) into a Markdown transcript
file using yt-dlp -> ffmpeg -> whisper-cli, matching the existing output
format in HeyTony/transcripts/<platform>/.

This module has no knowledge of native messaging — host.py drives it.
"""

import os
import re
import shutil
import subprocess
import time
from pathlib import Path


PLATFORM_LABELS = {
    "tiktok": "TikTok",
    "instagram": "Instagram",
    "facebook": "Facebook",
    "youtube": "YouTube",
}


def expand(path: str) -> Path:
    return Path(os.path.expanduser(os.path.expandvars(path)))


VENV_YT_DLP = Path(__file__).resolve().parent / ".venv" / "bin" / "yt-dlp"


def resolve_yt_dlp(settings: dict) -> str:
    """Prefer the companion venv's yt-dlp over the configured one.

    The venv has curl_cffi installed, which --impersonate requires; without it
    yt-dlp warns "no impersonate target is available" and TikTok 403s every
    download. A system yt-dlp configured in settings typically lacks it.
    """
    if VENV_YT_DLP.exists():
        return str(VENV_YT_DLP)
    return settings.get("ytDlpPath", "yt-dlp")


def slugify(text: str) -> str:
    """Identical rule to extract_instagram.py so filenames stay consistent."""
    text = text.split("\n")[0]
    text = re.sub(r"[^\w\s-]", "", text).strip().lower()
    text = re.sub(r"[-\s]+", "_", text)
    return text[:100]


_current_proc = None  # set by run_command while a child is in flight

DEBUG_LOG_NAME = "companion-debug.log"


def debug_log_path(output_dir: str) -> Path:
    return expand(output_dir) / DEBUG_LOG_NAME


def read_debug_log(output_dir: str, max_bytes: int = 400_000) -> str:
    """Return the tail of the debug log, bounded so a huge file can't wedge
    native messaging (Chrome caps a single message at 1MB)."""
    path = debug_log_path(output_dir)
    if not path.exists():
        return ""
    size = path.stat().st_size
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        if size > max_bytes:
            f.seek(size - max_bytes)
            f.readline()  # drop the partial first line from the seek
        return f.read()


def debug_log(output_dir: str, ctx: dict, cmd, returncode, stdout, stderr):
    """Append one full, untruncated record of a subprocess run.

    The `reason` field sent back to the extension is truncated (short enough
    for a popup log line); this file is the only place the complete
    stdout/stderr survives, for diagnosing exactly what happened after the
    fact instead of guessing from a clipped error string.
    """
    try:
        lines = [
            f"==== {time.strftime('%Y-%m-%dT%H:%M:%S')} | "
            f"{ctx.get('platform')} {ctx.get('vid')} | {ctx.get('step')} | "
            f"exit={returncode} ====",
            f"CMD: {' '.join(str(c) for c in cmd)}",
            "STDOUT:",
            stdout or "(empty)",
            "STDERR:",
            stderr or "(empty)",
            "",
        ]
        path = debug_log_path(output_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except OSError:
        pass  # debug logging is best-effort, never fatal to the pipeline


def log_event(output_dir: str, ctx: dict, message: str):
    """Append a single timestamped, non-subprocess event line to
    companion-debug.log — item lifecycle markers (start + URL, decision
    points like caption/audio checks, final outcome) that don't come from a
    single subprocess call. Lets the log read as one continuous per-item
    story instead of only showing isolated download/ffmpeg/whisper dumps
    with gaps in between.
    """
    try:
        line = (
            f"---- {time.strftime('%Y-%m-%dT%H:%M:%S')} | "
            f"{ctx.get('platform')} {ctx.get('vid')} | {message}"
        )
        path = debug_log_path(output_dir)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass  # debug logging is best-effort, never fatal to the pipeline


def kill_current_proc():
    """Kill whatever subprocess run_command is currently blocked on.

    host.py calls this from a SIGTERM handler: Chrome terminates the
    companion process when the extension disconnects the native port (e.g.
    Cancel), but Python's default SIGTERM handling kills only the parent —
    any in-flight yt-dlp/ffmpeg/whisper-cli child would otherwise be silently
    orphaned and keep running (as happened for hours with a stuck ffmpeg
    conversion before this existed).
    """
    if _current_proc is not None and _current_proc.poll() is None:
        _current_proc.kill()


def run_command(cmd, retries=3, retry_delay=5, timeout=300, debug=None):
    """Run a subprocess with retry/backoff on transient rate-limit errors.

    Returns (stdout, None) on success or (None, stderr) on failure. `timeout`
    bounds each attempt so a stalled process (e.g. yt-dlp blocked on a
    cookie-decrypt prompt) can't hang the companion's single-threaded message
    loop forever — without this, host.py has no way to notice or recover,
    since it can't read new messages (including cancel) while a subprocess
    call is blocked.

    `debug`, if given, is `(output_dir, ctx)` — every attempt's full,
    untruncated stdout/stderr gets appended to companion-debug.log via
    debug_log(), regardless of outcome. The (stdout, err) returned here stays
    truncated for the compact reason shown in the UI.
    """
    global _current_proc
    last_err = ""
    for attempt in range(retries):
        try:
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
        except FileNotFoundError as e:
            err = f"binary not found: {cmd[0]} ({e})"
            if debug:
                debug_log(debug[0], debug[1], cmd, "n/a", "", err)
            return None, err

        _current_proc = proc
        try:
            stdout, stderr = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()
            last_err = f"timed out after {timeout}s"
            if debug:
                debug_log(debug[0], debug[1], cmd, "timeout", "", last_err)
            if attempt < retries - 1:
                time.sleep(retry_delay)
                retry_delay *= 2
                continue
            return None, last_err
        finally:
            _current_proc = None

        if debug:
            debug_log(debug[0], debug[1], cmd, proc.returncode, stdout, stderr)

        if proc.returncode == 0:
            return stdout, None

        last_err = (stderr or "")[:500]
        low = last_err.lower()
        transient = (
            "empty media response" in low
            or "rate" in low
            or "timed out" in low
            # TikTok's JS-challenge solver intermittently 403s even with a
            # valid browser impersonation; a retry usually clears it.
            or "403" in low
            or "forbidden" in low
            # YouTube 429s caption fetches in bursts; a backed-off retry
            # usually gets through.
            or "429" in low
            or "too many requests" in low
            # Long single-stream downloads (e.g. a >1hr YouTube video's audio
            # track) sometimes have their connection cut mid-transfer by the
            # CDN or a flaky network hop — yt-dlp already retries 10x inside
            # one invocation before giving up, but a fresh process (new
            # connection, new format resolution) often succeeds where those
            # in-process retries didn't.
            or "connection closed abruptly" in low
            or "connection reset" in low
            or "http error 500" in low
            or "http error 502" in low
            or "http error 503" in low
        )
        if transient and attempt < retries - 1:
            time.sleep(retry_delay)
            retry_delay *= 2
            continue
        return None, last_err
    return None, last_err


def video_url(platform: str, item: dict) -> str:
    """Prefer the scraped permalink; fall back to a platform URL template."""
    permalink = item.get("permalink")
    if permalink:
        return permalink
    vid = item["id"]
    if platform == "tiktok":
        return f"https://www.tiktok.com/@i/video/{vid}"
    if platform == "instagram":
        return f"https://www.instagram.com/reel/{vid}/"
    if platform == "facebook":
        return f"https://www.facebook.com/reel/{vid}/"
    if platform == "youtube":
        return f"https://www.youtube.com/watch?v={vid}"
    return vid


def impersonate_args(settings: dict):
    """yt-dlp flags to mimic a real browser's TLS fingerprint.

    TikTok 403s plain requests; it only serves the JS-challenge cookie to a
    client whose TLS handshake matches a real browser. yt-dlp can do this via
    curl_cffi (installed in companion/.venv). Returns [] when disabled so a
    yt-dlp build without curl_cffi still runs (it just won't pass TikTok).
    """
    target = settings.get("impersonateTarget", "chrome")
    return ["--impersonate", target] if target else []


def ffmpeg_location_args(settings: dict):
    """Point yt-dlp at the configured ffmpeg explicitly.

    Chrome spawns the companion with a minimal PATH that usually lacks
    /usr/local/bin and /opt/homebrew/bin, so yt-dlp's own ffmpeg lookup fails
    and post-processing (e.g. --convert-subs srt) errors with "ffmpeg not
    found" even though ffmpeg is installed.
    """
    ffmpeg = settings.get("ffmpegPath", "")
    return ["--ffmpeg-location", ffmpeg] if ffmpeg else []


def resolve_node():
    """Locate a Node.js binary, beyond what shutil.which("node") finds.

    Chrome launches this companion process via Native Messaging with its own
    minimal environment, not a login/interactive shell — so a PATH entry
    added by e.g. nvm's shell rc hook (~/.nvm/versions/node/<ver>/bin) is
    invisible here even though `which node` finds it fine in a terminal.
    Fall back to the locations nvm and Homebrew actually install to.
    """
    found = shutil.which("node")
    if found:
        return found
    for candidate in ("/opt/homebrew/bin/node", "/usr/local/bin/node"):
        if Path(candidate).exists():
            return candidate
    nvm_versions = sorted(Path.home().glob(".nvm/versions/node/*/bin/node"), reverse=True)
    if nvm_versions:
        return str(nvm_versions[0])
    return None


def js_runtime_args():
    """yt-dlp flags to enable a JS runtime for YouTube's signature challenges.

    yt-dlp only auto-probes for `deno` by default; without it (or an explicit
    --js-runtimes flag) it can't solve YouTube's signature/n-challenge, so
    real video formats are unavailable and only images are offered — every
    -f ba/b download then fails with "Requested format is not available"
    even though the extraction itself succeeded. Node is a lighter-weight
    runtime that's much more likely to already be on the machine, so prefer
    it when present; otherwise no-op, matching impersonate_args()'s pattern
    of degrading gracefully rather than hard-failing on a missing binary.

    The resolved path is passed explicitly (node:<path>) rather than bare
    "node", because yt-dlp is itself a subprocess that inherits this
    process's PATH — the same PATH gap resolve_node() works around applies
    to yt-dlp's own lookup, so a bare runtime name would silently no-op
    exactly like shutil.which("node") does.
    """
    node = resolve_node()
    return ["--js-runtimes", f"node:{node}"] if node else []


def resolve_ffprobe(settings: dict):
    """Derive ffprobe's path from the configured ffmpeg path (sibling binary
    in the same install), matching how resolve_yt_dlp derives its own path.
    Returns None if ffmpeg's path isn't set or ffprobe isn't next to it —
    callers must treat that as "can't check, don't block on it".
    """
    ffmpeg = settings.get("ffmpegPath", "")
    if not ffmpeg:
        return None
    candidate = str(Path(ffmpeg).with_name("ffprobe"))
    return candidate if shutil.which(candidate) else None


def has_audio_stream(ffprobe: str, media_path: Path) -> bool:
    """True if the file has at least one audio stream, False if it doesn't.

    Distinguishes "silent video" from "video with an inaudible/wordless audio
    track" — the former should never even reach whisper.
    """
    try:
        proc = subprocess.run(
            [ffprobe, "-v", "error", "-select_streams", "a",
             "-show_entries", "stream=index", "-of", "csv=p=0", str(media_path)],
            capture_output=True, text=True, timeout=30,
        )
    except (OSError, subprocess.TimeoutExpired):
        return True  # can't tell — don't block the normal ffmpeg path
    return bool(proc.stdout.strip())


class Codes:
    OK_CAPTIONS = "OK_CAPTIONS"
    OK_WHISPER = "OK_WHISPER"
    SKIPPED_EXISTS = "SKIPPED_EXISTS"
    NO_SPEECH_NO_AUDIO = "NO_SPEECH_NO_AUDIO"
    NO_SPEECH_EMPTY = "NO_SPEECH_EMPTY"
    E_DOWNLOAD = "E_DOWNLOAD"
    E_NO_FILE = "E_NO_FILE"
    E_FFMPEG = "E_FFMPEG"
    E_WHISPER = "E_WHISPER"
    E_WHISPER_NO_OUTPUT = "E_WHISPER_NO_OUTPUT"
    E_UNEXPECTED = "E_UNEXPECTED"


_NON_SPEECH_MARKER_RE = re.compile(r"\[[^\]]*\]|\([^)]*\)")


def is_speechless(transcript_text: str) -> bool:
    """True if whisper's output has nothing but non-speech markers.

    whisper-cli emits bracketed/parenthetical tags like [BLANK_AUDIO],
    [MUSIC], or (background noise) instead of words when there's audio but
    nothing intelligible to transcribe. Stripping those and checking what's
    left distinguishes that case from a genuine (if short) transcript.
    """
    return not _NON_SPEECH_MARKER_RE.sub("", transcript_text).strip()


def transcript_dir(output_dir: str, platform: str) -> Path:
    return expand(output_dir) / "transcripts" / platform


def existing_transcript(output_dir: str, platform: str, vid: str):
    d = transcript_dir(output_dir, platform)
    matches = list(d.glob(f"transcript_{vid}_*.md"))
    return matches[0] if matches else None


def write_transcript(target_path: Path, transcript_text: str, description: str,
                      platform: str, account_title: str) -> None:
    title_line = description.split("\n")[0]
    label = PLATFORM_LABELS.get(platform, platform.title())

    markdown = f"""---
Tags: {label} > {account_title}
---

# {title_line}

## Table of Contents
- [Transcript](#transcript)

---

## Transcript
{transcript_text}
"""
    target_path.write_text(markdown)


_SRT_INDEX_RE = re.compile(r"^\d+$")
_SRT_TIME_RE = re.compile(r"^\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[,.]\d{3}")
_SRT_TAG_RE = re.compile(r"<[^>]+>")


def srt_to_text(path: Path) -> str:
    """Strip SRT sequence numbers, timing cues, and inline tags, and collapse
    consecutive duplicate lines — YouTube's auto-captions repeat a line across
    overlapping rolling cues, so a naive join doubles half the transcript."""
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    out = []
    for raw in lines:
        line = raw.strip()
        if not line or _SRT_INDEX_RE.match(line) or _SRT_TIME_RE.match(line):
            continue
        line = _SRT_TAG_RE.sub("", line)
        if out and out[-1] == line:
            continue
        out.append(line)
    return "\n".join(out).strip()


def extract_youtube_captions(yt_dlp: str, url: str, vid: str, cache_dir: Path,
                              settings: dict, debug=None):
    """Fetch YouTube's own captions (manual or auto-generated) via yt-dlp
    instead of downloading audio — faster, free of local CPU/GPU cost, and
    usually more accurate than local whisper for clear speech. Returns
    (transcript_text, title): text is None if the video has no captions in
    the configured language (caller falls back to the audio -> whisper path
    in that case); title is the video's title, or None if yt-dlp couldn't
    resolve it.

    The title is captured in this same request via --print-to-file rather
    than --print, because run_command discards stdout on a non-zero exit and
    a failed subtitle fetch (e.g. a 429) would take the title with it.

    `debug`, if given, is `(output_dir, ctx)` — forwarded to run_command so
    this attempt (including a "no captions found" outcome) lands in
    companion-debug.log like every other step, instead of being silently
    invisible to it.
    """
    # ".*-orig" is YouTube's auto-caption track in the video's spoken
    # language. A fixed language like "en" gets a machine translation for
    # non-English videos, and those translated tracks are the ones YouTube
    # 429s most readily.
    lang = settings.get("subtitleLang", ".*-orig")
    cookies_browser = settings.get("cookiesBrowser", "chrome")
    out_stem = cache_dir / f"{vid}_captions"
    title_file = cache_dir / f"{vid}_title.txt"
    title = None
    srt_files = []
    # Anonymous first: with browser cookies yt-dlp uses YouTube's web client,
    # which withholds the original-language auto-captions unless given a PO
    # token. Cookies are only the fallback, for videos that need a login
    # (age-restricted, members-only).
    for cookie_args in ([], ["--cookies-from-browser", cookies_browser]):
        title_file.unlink(missing_ok=True)  # --print-to-file appends
        cmd = [
            yt_dlp,
            "--skip-download",
            "--no-playlist",
            "--write-auto-sub",
            "--write-sub",
            "--sub-langs", lang,
            "--convert-subs", "srt",
            *ffmpeg_location_args(settings),
            *cookie_args,
            "--print-to-file", "%(title)s", str(title_file),
            "--no-progress",
            "-o", str(out_stem),
            url,
        ]
        # A video with no captions in this language isn't a pipeline error,
        # just an empty result — ignore run_command's err and check for the
        # file. Short, low-retry timeout: this is just a subtitle fetch and
        # should be quick, and a slow/no-caption video should fall back to
        # whisper promptly rather than eating the default 300s budget three
        # times over.
        run_command(cmd, retries=2, retry_delay=3, timeout=45, debug=debug)

        if title_file.exists():
            title = title_file.read_text(encoding="utf-8").strip().split("\n")[0] or title
            title_file.unlink(missing_ok=True)

        srt_files = list(cache_dir.glob(f"{vid}_captions*.srt"))
        if srt_files:
            break

    if not srt_files:
        if debug:
            log_event(debug[0], debug[1], f"captions: no {lang} subtitle file produced")
        return None, title
    text = srt_to_text(srt_files[0])
    for f in cache_dir.glob(f"{vid}_captions*"):
        f.unlink(missing_ok=True)
    if debug:
        log_event(debug[0], debug[1], f"captions: got {lang} subtitles, {len(text)} chars")
    return text or None, title


def extract_one(platform: str, item: dict, settings: dict, output_dir: str,
                account_title: str = "", progress_cb=None):
    """Run the full pipeline for one video.

    Returns a dict: {"status": "done"|"skipped"|"no_speech"|"failed",
                     "code": str, "reason": str|None, "path": str|None}.
    "no_speech" means the pipeline ran fine but there was nothing to
    transcribe (no audio track, or audio with no discernible words) — not a
    failure. Every full stdout/stderr for every step, plus non-subprocess
    lifecycle markers (START with the video URL, decision points, and a
    final OUTCOME line), lands in companion-debug.log (see debug_log() /
    log_event()) so a single item's whole story is traceable by grepping its
    id; `reason` here stays short.
    """
    vid = item["id"]
    ctx = {"platform": platform, "vid": vid}
    url = video_url(platform, item)
    log_event(output_dir, ctx, f"START url={url}")
    try:
        result = _extract_one(platform, item, settings, output_dir, account_title,
                               progress_cb, url, ctx)
    except Exception as e:
        log_event(output_dir, ctx, f"OUTCOME status=failed code={Codes.E_UNEXPECTED} reason={e!r}")
        raise
    log_event(output_dir, ctx,
               f"OUTCOME status={result['status']} code={result['code']} reason={result['reason']}")
    return result


def _extract_one(platform: str, item: dict, settings: dict, output_dir: str,
                  account_title: str, progress_cb, url: str, ctx: dict):
    vid = item["id"]
    yt_dlp = resolve_yt_dlp(settings)
    ffmpeg = settings["ffmpegPath"]
    whisper_cli = settings["whisperCliPath"]
    model = str(expand(settings["whisperModelPath"]))
    cookies_browser = settings.get("cookiesBrowser", "chrome")
    ffprobe = resolve_ffprobe(settings)

    out_dir = transcript_dir(output_dir, platform)
    out_dir.mkdir(parents=True, exist_ok=True)
    cache_dir = expand(output_dir) / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)

    # Idempotency: skip if a transcript for this id already exists.
    if existing_transcript(output_dir, platform, vid):
        return {"status": "skipped", "code": Codes.SKIPPED_EXISTS,
                "reason": "already exists", "path": None}

    # 1. Caption / title — prefer what the scraper already collected. When it's
    # missing, the download call below prints the description in the same
    # yt-dlp invocation (--print + --no-simulate) rather than making a separate
    # metadata request first — one TikTok round-trip per video instead of two,
    # which halves the rate-limit exposure.
    description = (item.get("caption") or "").strip()

    # YouTube exposes real captions via yt-dlp; try that before falling back
    # to the audio -> whisper path everyone else uses. The same request also
    # resolves the title when the scraper couldn't supply one (Shorts, or a
    # watch page read mid-SPA-navigation).
    def notify(phase):
        if progress_cb:
            try:
                progress_cb(phase)
            except Exception:
                pass

    def dbg(step):
        return (output_dir, {**ctx, "step": step})

    if platform == "youtube":
        notify("captions")
        captions_text, title = extract_youtube_captions(
            yt_dlp, url, vid, cache_dir, settings, debug=dbg("captions")
        )
        if not description:
            description = title or f"{platform}_{vid}"
        if captions_text:
            clean_title = slugify(description)
            target_path = out_dir / f"transcript_{vid}_{clean_title}.md"
            write_transcript(target_path, captions_text, description, platform, account_title)
            return {"status": "done", "code": Codes.OK_CAPTIONS, "reason": None,
                    "path": str(target_path)}
        # No captions in the configured language -> fall through to whisper.

    # Everything past here ends in whisper, so a missing model would only
    # surface after a full download and conversion, as whisper-cli's
    # unhelpful backend-loading noise. Fail up front with the real cause.
    if not Path(model).exists():
        return {"status": "failed", "code": Codes.E_WHISPER,
                "reason": f"whisper model not found at {model}", "path": None}

    # 2. Download best audio.
    temp_video = cache_dir / f"{vid}_tmp"
    wav_path = cache_dir / f"{vid}.wav"
    # "ba/b": prefer an audio-only stream (Instagram exposes one), but fall back
    # to the best combined stream (TikTok serves only progressive MP4). The wav
    # conversion step below extracts audio either way.
    # --no-playlist: a YouTube watch URL carrying list= would otherwise
    # download every video in that playlist.
    download_cmd = [
        yt_dlp,
        "--no-playlist",
        "--cookies-from-browser", cookies_browser,
        *impersonate_args(settings),
        *js_runtime_args(),
        *ffmpeg_location_args(settings),
        "-f", "ba/b",
        "-o", str(temp_video),
    ]
    if not description:
        # A YouTube description is a long blurb, not a heading; the title is
        # what belongs in the markdown title and filename.
        field = "%(title)s" if platform == "youtube" else "%(description)s"
        download_cmd += ["--print", field, "--no-simulate", "--no-progress"]
    download_cmd.append(url)
    notify("download")
    dl_out, err = run_command(download_cmd, timeout=600, debug=dbg("download"))
    if err is not None:
        return {"status": "failed", "code": Codes.E_DOWNLOAD,
                "reason": f"download: {err[:160]}", "path": None}

    if not description:
        description = (dl_out or "").strip()
    if not description:
        description = f"{platform}_{vid}"

    clean_title = slugify(description)
    target_path = out_dir / f"transcript_{vid}_{clean_title}.md"

    downloaded = list(cache_dir.glob(f"{vid}_tmp*"))
    if not downloaded:
        return {"status": "failed", "code": Codes.E_NO_FILE,
                "reason": "download produced no file", "path": None}
    actual_temp = downloaded[0]

    # 2b. Some videos simply have no audio track (e.g. silent clips). Catch
    # that here so it's reported as "nothing to transcribe" rather than
    # letting ffmpeg fail obscurely a step later.
    if ffprobe:
        has_audio = has_audio_stream(ffprobe, actual_temp)
        log_event(output_dir, ctx, f"ffprobe: has_audio_stream={has_audio}")
        if not has_audio:
            actual_temp.unlink(missing_ok=True)
            return {"status": "no_speech", "code": Codes.NO_SPEECH_NO_AUDIO,
                    "reason": "No spoken words to transcribe", "path": None}

    # 3. Convert to 16 kHz mono PCM WAV (Whisper requirement).
    convert_cmd = [
        ffmpeg,
        "-i", str(actual_temp),
        "-ar", "16000",
        "-ac", "1",
        "-c:a", "pcm_s16le",
        "-y",
        str(wav_path),
    ]
    notify("ffmpeg")
    _, err = run_command(convert_cmd, timeout=300, debug=dbg("ffmpeg"))
    actual_temp.unlink(missing_ok=True)
    if err is not None:
        return {"status": "failed", "code": Codes.E_FFMPEG,
                "reason": f"ffmpeg: {err[:160]}", "path": None}

    # 4. Transcribe.
    txt_path = cache_dir / f"{vid}.wav.txt"
    whisper_cmd = [
        whisper_cli,
        "-m", model,
        "-f", str(wav_path),
        "-otxt",
        "-nt",
    ]
    # English-only models (*.en) reject other languages; for multilingual
    # models let whisper detect the language instead of its default of "en".
    if ".en" not in Path(model).name:
        whisper_cmd += ["-l", "auto"]
    notify("whisper")
    _, err = run_command(whisper_cmd, timeout=1800, debug=dbg("whisper"))
    if err is not None:
        wav_path.unlink(missing_ok=True)
        return {"status": "failed", "code": Codes.E_WHISPER,
                "reason": f"whisper: {err[:160]}", "path": None}

    if not txt_path.exists():
        wav_path.unlink(missing_ok=True)
        return {"status": "failed", "code": Codes.E_WHISPER_NO_OUTPUT,
                "reason": "whisper produced no output", "path": None}

    transcript_text = txt_path.read_text().strip()
    wav_path.unlink(missing_ok=True)
    txt_path.unlink(missing_ok=True)

    # Audio existed but whisper found nothing intelligible in it (e.g.
    # instrumental music, ambient noise) — distinct from a pipeline failure.
    if is_speechless(transcript_text):
        log_event(
            output_dir, ctx,
            f"whisper: output judged speechless ({len(transcript_text)} chars): {transcript_text[:200]!r}",
        )
        return {"status": "no_speech", "code": Codes.NO_SPEECH_EMPTY,
                "reason": "No spoken words to transcribe", "path": None}

    write_transcript(target_path, transcript_text, description, platform, account_title)

    return {"status": "done", "code": Codes.OK_WHISPER, "reason": None,
            "path": str(target_path)}


def check_setup(settings: dict):
    """Verify all binaries + model exist and are runnable. Returns checks list."""
    checks = []

    # yt-dlp is checked via resolve_yt_dlp (not the raw setting) because the
    # companion venv's copy takes precedence at extraction time too.
    yt_dlp = resolve_yt_dlp(settings)
    yp = expand(yt_dlp)
    if not yp.exists():
        checks.append({"name": "yt-dlp", "ok": False, "detail": f"not found at {yt_dlp}"})
    else:
        try:
            subprocess.run(
                [str(yp), "--version"], capture_output=True, text=True, timeout=15
            )
            checks.append({"name": "yt-dlp", "ok": True, "detail": str(yp)})
        except Exception as e:  # noqa: BLE001
            checks.append({"name": "yt-dlp", "ok": False, "detail": f"failed to run: {e}"})
        try:
            r = subprocess.run(
                [str(yp), "--list-impersonate-targets"],
                capture_output=True, text=True, timeout=15,
            )
            usable = any(
                "curl_cffi" in line and "unavailable" not in line
                for line in r.stdout.splitlines()
            )
            if usable:
                checks.append({
                    "name": "impersonation (curl_cffi)", "ok": True,
                    "detail": "browser TLS targets available",
                })
            else:
                checks.append({
                    "name": "impersonation (curl_cffi)", "ok": False,
                    "detail": "no targets — TikTok will 403 every download; "
                              "reinstall companion/.venv with curl_cffi",
                })
        except Exception as e:  # noqa: BLE001
            checks.append({
                "name": "impersonation (curl_cffi)", "ok": False,
                "detail": f"failed to check: {e}",
            })

    for name, key, version_arg in [
        ("ffmpeg", "ffmpegPath", "-version"),
        ("whisper-cli", "whisperCliPath", "--help"),
    ]:
        path = settings.get(key, "")
        p = expand(path)
        if not p.exists():
            checks.append({"name": name, "ok": False, "detail": f"not found at {path}"})
            continue
        try:
            subprocess.run(
                [str(p), version_arg],
                capture_output=True,
                text=True,
                timeout=15,
            )
            checks.append({"name": name, "ok": True, "detail": str(p)})
        except Exception as e:  # noqa: BLE001
            checks.append({"name": name, "ok": False, "detail": f"failed to run: {e}"})

    model_path = settings.get("whisperModelPath", "")
    mp = expand(model_path)
    if mp.exists():
        size_mb = mp.stat().st_size // (1024 * 1024)
        checks.append({"name": "whisper model", "ok": True, "detail": f"{mp} ({size_mb} MB)"})
    else:
        checks.append({"name": "whisper model", "ok": False, "detail": f"not found at {model_path}"})

    return checks
