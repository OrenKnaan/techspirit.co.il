const views = {
  unsupported: document.getElementById("unsupported"),
  ready: document.getElementById("ready"),
  running: document.getElementById("running"),
  done: document.getElementById("done"),
  error: document.getElementById("error"),
  report: document.getElementById("report"),
};

const accountTitleEl = document.getElementById("account-title");
const progressFill = document.getElementById("progress-fill");
const progressText = document.getElementById("progress-text");
const statusLine = document.getElementById("status-line");
const logEl = document.getElementById("log");
const doneSummary = document.getElementById("done-summary");
const errorText = document.getElementById("error-text");

let currentTabId = null;
let currentRun = null;
let billing = null; // { credits, devAccount, pricePerTranscript, pack, remaining, ... }
let altHeld = false;
let countdownTimer = null;

const upgradeBox = document.getElementById("upgrade-box");
const upgradeWait = document.getElementById("upgrade-wait");
const upgradeNote = document.getElementById("upgrade-note");
const buyAllLabel = document.getElementById("buy-all-label");
const buyAllBtn = document.getElementById("buy-all-btn");
const simHint = document.getElementById("sim-hint");

// Track the Option/Alt key so the dev account can arm simulated payments.
document.addEventListener("keydown", (e) => {
  if (e.key === "Alt") { altHeld = true; updateSimHint(); }
});
document.addEventListener("keyup", (e) => {
  if (e.key === "Alt") { altHeld = false; updateSimHint(); }
});
window.addEventListener("blur", () => { altHeld = false; updateSimHint(); });

function updateSimHint() {
  if (!billing || !billing.devAccount) return;
  simHint.classList.remove("hidden");
  simHint.textContent = altHeld
    ? "Simulated payment armed — click a button to add credits free."
    : "Dev account: hold ⌥ Option and click to simulate payment.";
}

function showView(name) {
  for (const key of Object.keys(views)) {
    views[key].classList.toggle("hidden", key !== name);
  }
}

function statusLabel(status) {
  return {
    discovering: "Scanning the page for videos…",
    extracting: "Transcribing videos…",
    paused: "Paused.",
  }[status] || "";
}

function renderRun(run, pageInfo) {
  currentRun = run;

  if (pageInfo) {
    const credits = billing && billing.credits > 0
      ? ` <span class="credit-pill">${billing.credits} credit${billing.credits === 1 ? "" : "s"}</span>`
      : "";
    accountTitleEl.innerHTML =
      `${escapeHtml(pageInfo.platform)} · ${escapeHtml(pageInfo.pageTitle)}${credits}`;
  }

  if (!run || run.status === "cancelled") {
    // Cancelled runs offer a fresh Start (which resumes where they left off)
    // rather than an error + Retry.
    showView("ready");
    return;
  }

  if (run.status === "discovering" || run.status === "extracting" || run.status === "paused") {
    showView("running");
    statusLine.textContent = statusLabel(run.status);
    const paused = run.status === "paused";
    document.getElementById("pause-btn").classList.toggle("hidden", paused);
    document.getElementById("resume-btn").classList.toggle("hidden", !paused);

    const items = Object.values(run.items || {});
    const finished = items.filter((i) =>
      ["done", "skipped", "no_speech", "failed"].includes(i.status)
    ).length;
    const total = run.discoveryDone ? items.length : Math.max(items.length, run.discoveryTotal || 0);

    progressText.textContent = run.discoveryDone
      ? `${finished} / ${total}`
      : `${finished} found so far…`;
    progressFill.style.width = total > 0 ? `${(finished / total) * 100}%` : "0%";

    renderUpgrade(run);
    renderLog(items);
    return;
  }

  if (run.status === "done") {
    showView("done");
    const items = Object.values(run.items || {});
    const done = items.filter((i) => i.status === "done").length;
    const skipped = items.filter((i) => i.status === "skipped").length;
    const noSpeech = items.filter((i) => i.status === "no_speech").length;
    const failed = items.filter((i) => i.status === "failed").length;
    doneSummary.textContent =
      `${done} new transcripts, ${noSpeech} no speech, ${skipped} skipped, ${failed} failed.`;
    return;
  }

  if (run.status === "failed") {
    showView("error");
    errorText.textContent = run.failReason || "Something went wrong.";
    return;
  }
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])
  );
}

// Shows the upgrade offer whenever the free-tier wait is active or the first
// free extraction has prompted it. Hidden entirely once credits are held.
function renderUpgrade(run) {
  const hasCredits = billing && billing.credits > 0;
  const waitUntil = run.freeWaitUntil || 0;
  const waiting = !hasCredits && waitUntil > Date.now();
  const prompted = !hasCredits && run.upgradePrompt;

  if (!waiting && !prompted) {
    upgradeBox.classList.add("hidden");
    stopCountdown();
    return;
  }

  upgradeBox.classList.remove("hidden");

  // "Pay for all" price = remaining transcribable items * per-transcript price.
  if (billing) {
    const n = billing.remaining || 0;
    const price = (n * billing.pricePerTranscript).toFixed(2);
    buyAllLabel.textContent = n > 0
      ? `Pay $${price} — all ${n} on this page`
      : "Pay for all on this page";
    buyAllBtn.classList.toggle("hidden", n <= 0);
    upgradeNote.textContent = billing.paypalConfigured
      ? "Opens PayPal. After paying, click again to confirm and unlock."
      : "PayPal link not configured yet — simulated unlock only for now.";
  }

  updateSimHint();
  startCountdown(run);
}

function startCountdown(run) {
  stopCountdown();
  const tick = () => {
    const remainMs = (run.freeWaitUntil || 0) - Date.now();
    if (remainMs <= 0) {
      upgradeWait.textContent = "Extracting next transcript…";
      stopCountdown();
      return;
    }
    const s = Math.ceil(remainMs / 1000);
    const mm = String(Math.floor(s / 60)).padStart(1, "0");
    const ss = String(s % 60).padStart(2, "0");
    upgradeWait.innerHTML = `Free tier: next transcript in <span class="count">${mm}:${ss}</span>`;
  };
  tick();
  countdownTimer = setInterval(tick, 500);
}

function stopCountdown() {
  if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
}

async function purchase(plan) {
  const simulated = altHeld && billing && billing.devAccount;
  const count = plan === "all" ? (billing ? billing.remaining : 0) : undefined;

  const res = await chrome.runtime.sendMessage({
    type: "popup_purchase", plan, count, simulated,
  });
  if (!res || !res.ok) {
    if (res && res.error) upgradeNote.textContent = res.error;
    return;
  }
  if (res.needsPayment) {
    // Real payment: open PayPal (if configured), then a second click confirms.
    if (res.paypalUrl) chrome.tabs.create({ url: res.paypalUrl });
    upgradeNote.textContent = res.paypalUrl
      ? `Complete the $${res.price.toFixed(2)} payment in PayPal, then click again to unlock.`
      : "PayPal isn't configured. Ask the developer to set a PayPal.me handle.";
    // Arm the confirm: next click on the same plan grants credits (honor system).
    pendingConfirm = { plan, count };
    return;
  }
  pendingConfirm = null;
  refresh();
}

let pendingConfirm = null;

async function onBuyClick(plan) {
  // Second click after a real-payment prompt = honor-system confirmation.
  if (pendingConfirm && pendingConfirm.plan === plan && !(altHeld && billing.devAccount)) {
    const res = await chrome.runtime.sendMessage({
      type: "popup_purchase", plan, count: pendingConfirm.count, confirm: true,
    });
    pendingConfirm = null;
    if (res && res.ok) refresh();
    return;
  }
  purchase(plan);
}

document.getElementById("buy-pack-btn").addEventListener("click", () => onBuyClick("pack"));
buyAllBtn.addEventListener("click", () => onBuyClick("all"));

const STATUS_META = {
  pending: { color: "#3b6be0", label: "Pending" },
  sent: { color: "#e0b429", label: "Processing", blink: true },
  done: { color: "#1f9d55", label: "Done" },
  skipped: { color: "#9aa8c4", label: "Skipped" },
  no_speech: { color: "#7c5cd6", label: "No speech" },
  failed: { color: "#c0392b", label: "Failed" },
  cancelled: { color: "#1c1c1e", label: "Cancelled" },
};

function buildLogRow(item) {
  const meta = STATUS_META[item.status] || STATUS_META.pending;
  const row = document.createElement("div");
  row.className = "log-row";

  const dot = document.createElement("span");
  dot.className = "status-dot" + (meta.blink ? " blink" : "");
  dot.style.background = meta.color;
  row.appendChild(dot);

  const name = document.createElement("span");
  name.className = "log-filename";
  name.textContent = item.id;
  row.appendChild(name);

  const label = document.createElement("span");
  label.className =
    "status-label" +
    (item.status === "failed" ? " is-failed" : item.status === "done" ? " is-done" : "");

  if (item.status === "sent") {
    label.innerHTML =
      "Processing" + (item.phase ? ` <span class="phase">— ${escapeHtml(item.phase)}</span>` : "");
  } else if (item.status === "cancelled" && item.hadActivity) {
    label.innerHTML =
      `Cancelled <a href="#" class="info-link" data-item-id="${escapeHtml(item.id)}" ` +
      `title="See the last log entry for this item">&#9432;</a>`;
  } else if (item.status === "failed") {
    label.textContent = item.code ? `Failed (${item.code})` : "Failed";
  } else {
    label.textContent = meta.label;
  }
  row.appendChild(label);
  return row;
}

function renderRows(container, items) {
  container.innerHTML = "";
  for (const item of items) container.appendChild(buildLogRow(item));
  container.scrollTop = container.scrollHeight;
}

function renderLog(items) {
  renderRows(logEl, items);
}

function formatDuration(totalSeconds) {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

// Handles clicks on the "Cancelled ⓘ" links, wherever they appear (live log
// or the report modal's item snapshot).
document.body.addEventListener("click", (e) => {
  const link = e.target.closest(".info-link");
  if (!link) return;
  e.preventDefault();
  chrome.runtime.sendMessage({
    type: "popup_open_debug_log_for",
    itemId: link.dataset.itemId,
  });
});

const reportSummary = document.getElementById("report-summary");
const reportItemsEl = document.getElementById("report-items");
const reportNotes = document.getElementById("report-notes");
let reportMeta = null;

function showReportModal(run) {
  const items = Object.values(run.items || {}).map((item) => {
    if (["done", "skipped", "no_speech", "failed"].includes(item.status)) return item;
    return Object.assign({}, item, { status: "cancelled", hadActivity: item.status === "sent" });
  });

  const count = (status) => items.filter((i) => i.status === status).length;
  const done = count("done");
  const noSpeech = count("no_speech");
  const skipped = count("skipped");
  const failed = count("failed");
  const cancelled = count("cancelled");
  const durationS = Math.round((Date.now() - (run.startedAt || Date.now())) / 1000);

  reportMeta = {
    platform: run.platform,
    accountTitle: run.accountTitle,
    total: items.length,
    done, noSpeech, skipped, failed, cancelled, durationS,
  };

  reportSummary.textContent =
    `${done} transcript${done === 1 ? "" : "s"} generated in ${formatDuration(durationS)} — ` +
    `${noSpeech} no speech, ${skipped} skipped, ${failed} failed, ${cancelled} cancelled mid-run.`;

  renderRows(reportItemsEl, items);
  reportNotes.value = "";
  showView("report");
}

document.getElementById("report-close-btn").addEventListener("click", () => {
  refresh();
});

document.getElementById("report-open-folder-btn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "popup_open_folder" });
});

document.getElementById("report-send-btn").addEventListener("click", () => {
  const meta = reportMeta || {};
  const subject = encodeURIComponent(
    `Downscript bug report — ${meta.platform || ""} ${meta.accountTitle || ""}`.trim()
  );
  const lines = [
    `Platform: ${meta.platform || "?"}`,
    `Account/page: ${meta.accountTitle || "?"}`,
    `Extension version: ${chrome.runtime.getManifest().version}`,
    `Timestamp: ${new Date().toISOString()}`,
    "",
    `Results (of ${meta.total || 0} total): ${meta.done || 0} done, ${meta.noSpeech || 0} no speech, ` +
      `${meta.skipped || 0} skipped, ${meta.failed || 0} failed, ${meta.cancelled || 0} cancelled mid-run`,
    `Run duration: ${formatDuration(meta.durationS || 0)}`,
    "",
    "Notes from user:",
    reportNotes.value.trim() || "(none)",
  ];
  const body = encodeURIComponent(lines.join("\n"));
  chrome.tabs.create({ url: `mailto:?subject=${subject}&body=${body}` });
});

async function refresh() {
  const res = await chrome.runtime.sendMessage({ type: "popup_get_state" });
  if (!res) return;
  currentTabId = res.tabId;
  billing = res.billing || null;

  if (!res.pageInfo || !res.pageInfo.supported) {
    showView("unsupported");
    return;
  }

  renderRun(res.run, res.pageInfo);
}

document.getElementById("start-btn").addEventListener("click", async () => {
  showView("running");
  statusLine.textContent = "Starting…";
  progressText.textContent = "";
  const res = await chrome.runtime.sendMessage({ type: "popup_start", tabId: currentTabId });
  if (!res.ok) {
    showView("error");
    errorText.textContent = res.error;
  }
});

document.getElementById("rerun-btn").addEventListener("click", async () => {
  showView("running");
  const res = await chrome.runtime.sendMessage({ type: "popup_start", tabId: currentTabId });
  if (!res.ok) {
    showView("error");
    errorText.textContent = res.error;
  }
});

document.getElementById("retry-btn").addEventListener("click", async () => {
  showView("running");
  const res = await chrome.runtime.sendMessage({ type: "popup_start", tabId: currentTabId });
  if (!res.ok) {
    showView("error");
    errorText.textContent = res.error;
  }
});

document.getElementById("cancel-btn").addEventListener("click", async () => {
  const snapshot = currentRun;
  await chrome.runtime.sendMessage({ type: "popup_cancel", tabId: currentTabId });
  if (snapshot) {
    showReportModal(snapshot);
    return;
  }
  refresh();
});

document.getElementById("pause-btn").addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "popup_pause", tabId: currentTabId });
  refresh();
});

document.getElementById("resume-btn").addEventListener("click", async () => {
  // Resume reuses popup_start: the background treats any non-done run as a
  // resume (re-sends pending items, restarts discovery if it never finished).
  const res = await chrome.runtime.sendMessage({ type: "popup_start", tabId: currentTabId });
  if (!res.ok) {
    showView("error");
    errorText.textContent = res.error;
  } else {
    refresh();
  }
});

document.getElementById("open-folder-btn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "popup_open_folder" });
});

document.getElementById("open-folder-btn-2").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "popup_open_folder" });
});

document.getElementById("settings-btn").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "state_update") {
    refresh();
  }
});

refresh();
