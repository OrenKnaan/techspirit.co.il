// PlatformAdapter implementation for Instagram profile grids / reels tabs.
// See TECHNICAL_DESIGN.md §3.1/§6 for the adapter contract.
//
// Collection targets /reel/<shortcode>/ hrefs: on the reels tab every tile
// links there, and on the main profile grid modern Instagram links reel
// tiles there too. /p/<shortcode>/ links are NOT collected — they're images
// and carousels, and telling video-carousels apart requires locale-dependent
// aria-label sniffing (the original EdwardStrum workflow also collected from
// the reels tab only, which is what its shortcodes.txt was built from).
(function () {
  // instagram.com/<username>/ or instagram.com/<username>/reels/, excluding
  // Instagram's own non-profile top-level routes.
  const PROFILE_RE =
    /^https?:\/\/(www\.)?instagram\.com\/([^/?#]+)\/?(reels\/?)?([?#].*)?$/;
  const RESERVED = new Set([
    "p", "reel", "reels", "explore", "accounts", "direct", "stories",
    "about", "developer", "legal", "session", "challenge",
  ]);
  const REEL_ID_RE = /\/reel\/([A-Za-z0-9_-]+)/;

  function usernameFrom(url) {
    const m = url.match(PROFILE_RE);
    if (!m) return null;
    const first = m[2].toLowerCase();
    return RESERVED.has(first) ? null : m[2];
  }

  function matches(url) {
    return usernameFrom(url) !== null;
  }

  function getPageTitle() {
    return usernameFrom(window.location.href) || "instagram_profile";
  }

  // Instagram virtualizes the grid like TikTok does — only a window of tiles
  // exists in the DOM at any time; scraper.js accumulates across scrolls.
  function findVideoTiles() {
    const anchors = Array.from(document.querySelectorAll('a[href*="/reel/"]'));
    const byId = new Map();
    for (const a of anchors) {
      const m = a.href.match(REEL_ID_RE);
      if (!m) continue;
      if (!byId.has(m[1])) byId.set(m[1], a);
    }
    return Array.from(byId.entries()).map(([id, el]) => ({ id, el }));
  }

  // Instagram tile <img alt> usually carries the caption text (or a
  // generated description) — better than TikTok's tiles. When absent, the
  // companion gets the description from the download call itself.
  function extractCaption(el) {
    const img = el.querySelector("img[alt]");
    const alt = img && img.getAttribute("alt");
    if (alt && alt.trim()) return alt.trim();
    return null;
  }

  window.DownscriptAdapters = window.DownscriptAdapters || {};
  window.DownscriptAdapters.instagram = {
    platform: "instagram",
    matches,
    getPageTitle,
    findVideoTiles,
    extractCaption,
  };
})();
