// PlatformAdapter implementation for Facebook Reels pages (a page/profile's
// /reels/ tab). See TECHNICAL_DESIGN.md §3.1/§6 for the adapter contract.
//
// Facebook virtualizes its reels feed more aggressively than TikTok — tiles
// unmount quickly as you scroll — so this adapter only ever reflects the
// current window; scraper.js accumulates IDs across scrolls (same contract
// as the TikTok adapter).
(function () {
  const REELS_TAB_RE =
    /^https?:\/\/(www\.|web\.|m\.)?facebook\.com\/[^/?#]+\/reels\/?([?#].*)?$/;
  const REEL_ID_RE = /\/reel\/(\d+)/;

  function matches(url) {
    return REELS_TAB_RE.test(url);
  }

  function getPageTitle() {
    const m = window.location.pathname.match(/^\/([^/?#]+)\/reels/);
    return m ? m[1] : "facebook_reels";
  }

  function findVideoTiles() {
    const anchors = Array.from(document.querySelectorAll('a[href*="/reel/"]'));
    const byId = new Map();
    for (const a of anchors) {
      const m = a.href.match(REEL_ID_RE);
      if (!m) continue;
      if (!byId.has(m[1])) byId.set(m[1], a);
    }
    return Array.from(byId.entries()).map(([id, el]) => ({ id, el }));
  }

  // Reels-tab tiles show view counts, not captions, so this usually returns
  // null — the companion then gets the description from the same yt-dlp call
  // that downloads the video (see pipeline.extract_one).
  function extractCaption(el) {
    const label = el.getAttribute("aria-label");
    if (label && label.trim()) return label.trim();
    const img = el.querySelector("img[alt]");
    const alt = img && img.getAttribute("alt");
    if (alt && alt.trim()) return alt.trim();
    return null;
  }

  window.DownscriptAdapters = window.DownscriptAdapters || {};
  window.DownscriptAdapters.facebook = {
    platform: "facebook",
    matches,
    getPageTitle,
    findVideoTiles,
    extractCaption,
  };
})();
