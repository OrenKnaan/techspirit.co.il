// PlatformAdapter implementation for TikTok profile grids.
// See TECHNICAL_DESIGN.md §3.1/§6 for the adapter interface contract.
(function () {
  const PROFILE_RE = /^https?:\/\/(www\.)?tiktok\.com\/@([\w.-]+)\/?(\?.*)?$/;
  const VIDEO_ID_RE = /\/video\/(\d+)/;

  function matches(url) {
    return PROFILE_RE.test(url);
  }

  function getPageTitle() {
    const m = window.location.pathname.match(/^\/@([\w.-]+)/);
    return m ? m[1] : "tiktok_profile";
  }

  // TikTok virtualizes the grid, so this only ever reflects the current
  // scroll window — callers must accumulate across repeated calls.
  function findVideoTiles() {
    const anchors = Array.from(document.querySelectorAll('a[href*="/video/"]'));
    const byId = new Map();
    for (const a of anchors) {
      const m = a.href.match(VIDEO_ID_RE);
      if (!m) continue;
      if (!byId.has(m[1])) byId.set(m[1], a);
    }
    return Array.from(byId.entries()).map(([id, el]) => ({ id, el }));
  }

  // Best-effort only: the profile grid tile usually doesn't carry the full
  // caption (unlike Instagram's description, which extract_instagram.py can
  // fetch up front). When this returns null, the companion falls back to its
  // own `yt-dlp --print description` call per item.
  function extractCaption(el) {
    const img = el.querySelector("img[alt]");
    const alt = img && img.getAttribute("alt");
    if (alt && alt.trim()) return alt.trim();
    const title = el.getAttribute("title");
    if (title && title.trim()) return title.trim();
    return null;
  }

  window.DownscriptAdapters = window.DownscriptAdapters || {};
  window.DownscriptAdapters.tiktok = {
    platform: "tiktok",
    matches,
    getPageTitle,
    findVideoTiles,
    extractCaption,
  };
})();
