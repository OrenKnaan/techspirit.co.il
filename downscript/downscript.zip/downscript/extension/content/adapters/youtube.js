// PlatformAdapter implementations for YouTube playlist pages and single
// video (watch / Shorts) pages. See TECHNICAL_DESIGN.md §3.1/§6 for the
// adapter contract.
(function () {
  const PLAYLIST_RE = /^https?:\/\/(www\.|m\.)?youtube\.com\/playlist(\?|$)/;
  const WATCH_RE = /^https?:\/\/(www\.|m\.)?youtube\.com\/watch\?/;
  const SHORTS_RE = /^https?:\/\/(www\.|m\.)?youtube\.com\/shorts\/([\w-]{11})/;
  const VIDEO_ID_RE = /[?&]v=([\w-]{11})/;

  // Playlist rows: the legacy renderer, and the lockup view model YouTube
  // migrated playlist pages to. Lockups have no a#video-title at all, so the
  // old selector silently matched nothing and runs finished at 0/0.
  const ROW_SELECTOR = "ytd-playlist-video-renderer, yt-lockup-view-model";

  function listParam(url) {
    try {
      return new URL(url).searchParams.get("list");
    } catch (e) {
      return null;
    }
  }

  // Bare watch URL for yt-dlp. Row hrefs carry &list=…&index=…, and yt-dlp
  // given a watch URL with list= downloads the whole playlist.
  function watchUrl(id) {
    return `https://www.youtube.com/watch?v=${id}`;
  }

  // ---- Playlist pages ----------------------------------------------------

  function matchesPlaylist(url) {
    return PLAYLIST_RE.test(url) && !!listParam(url);
  }

  // Playlist header markup shifts over time, so try a couple of selectors
  // before falling back to document.title (stripped of " - YouTube") and,
  // as a last resort, the list= id itself — this must never return nothing,
  // since it becomes the output folder name.
  function getPlaylistTitle() {
    const header = document.querySelector(
      "yt-page-header-view-model h1, ytd-playlist-header-renderer #title, " +
        "ytd-playlist-sidebar-primary-info-renderer #title"
    );
    const headerText = header && header.textContent && header.textContent.trim();
    if (headerText) return headerText;

    const docTitle = document.title.replace(/\s*-\s*YouTube\s*$/, "").trim();
    if (docTitle) return docTitle;

    return listParam(window.location.href) || "youtube_playlist";
  }

  // YouTube lazy-loads additional rows as the playlist page scrolls, similar
  // to how TikTok/Instagram/Facebook virtualize their grids — scraper.js's
  // accumulate-across-scrolls loop handles this the same way.
  function findPlaylistTiles() {
    const list = listParam(window.location.href);
    const byId = new Map();
    for (const a of document.querySelectorAll('a[href*="/watch?v="]')) {
      const m = a.href.match(VIDEO_ID_RE);
      if (!m || byId.has(m[1])) continue;
      // Only rows linking into *this* playlist. This skips the header's Play
      // all / Shuffle buttons and any recommended-playlist shelves.
      const row = a.closest(ROW_SELECTOR);
      if (!row || listParam(a.href) !== list) continue;
      byId.set(m[1], row);
    }
    return Array.from(byId.entries()).map(([id, el]) => ({
      id,
      el,
      permalink: watchUrl(id),
    }));
  }

  // Unlike TikTok/Facebook tiles, playlist rows always show the real video
  // title — used as the markdown title in pipeline.extract_one. Lockup rows
  // keep the untruncated title in the heading's title attribute.
  function extractPlaylistCaption(row) {
    const titleEl = row.querySelector("#video-title, h3[title], h3 a");
    if (!titleEl) return null;
    const text = (titleEl.getAttribute("title") || titleEl.textContent || "").trim();
    return text || null;
  }

  // ---- Single video pages (watch / Shorts) -------------------------------

  function currentVideoId(url) {
    const shorts = url.match(SHORTS_RE);
    if (shorts) return shorts[2];
    if (!WATCH_RE.test(url)) return null;
    const m = url.match(VIDEO_ID_RE);
    return m ? m[1] : null;
  }

  function matchesVideo(url) {
    return currentVideoId(url) !== null;
  }

  // YouTube is an SPA: right after navigating, the URL is already the new
  // video while ytd-watch-flexy still shows the previous one's metadata.
  // Only trust the DOM once its video-id attribute has caught up.
  function watchDomFor(id) {
    const flexy = document.querySelector("ytd-watch-flexy");
    if (!flexy || flexy.getAttribute("video-id") !== id) return null;
    return flexy;
  }

  // Single videos are filed under their channel, so transcripts from
  // several videos of one channel land in the same folder.
  function getChannelName() {
    const id = currentVideoId(window.location.href);
    const flexy = id && watchDomFor(id);
    const link = flexy
      ? flexy.querySelector("ytd-watch-metadata ytd-channel-name a, #owner ytd-channel-name a")
      : document.querySelector(
          "ytd-reel-video-renderer[is-active] #channel-name a, " +
            "ytd-reel-video-renderer[is-active] yt-reel-channel-bar-view-model a"
        );
    const text = link && link.textContent && link.textContent.trim();
    return text || "youtube_videos";
  }

  // The run key is per video rather than per channel, so opening a second
  // video from the same channel starts a fresh run instead of showing (or
  // resuming) the first video's.
  function getVideoPageKey() {
    return `video:${currentVideoId(window.location.href)}`;
  }

  // el is the watch page container, or null when it isn't trustworthy
  // (Shorts, or mid-SPA-navigation). extractVideoCaption then returns null
  // and the companion resolves the title itself via yt-dlp.
  function findVideoTiles() {
    const id = currentVideoId(window.location.href);
    if (!id) return [];
    return [{ id, el: watchDomFor(id), permalink: watchUrl(id) }];
  }

  function extractVideoCaption(el) {
    if (!el) return null;
    const h1 = el.querySelector("ytd-watch-metadata h1");
    const text = h1 && h1.textContent && h1.textContent.trim();
    return text || null;
  }

  window.DownscriptAdapters = window.DownscriptAdapters || {};
  window.DownscriptAdapters.youtube = {
    platform: "youtube",
    matches: matchesPlaylist,
    getPageTitle: getPlaylistTitle,
    findVideoTiles: findPlaylistTiles,
    extractCaption: extractPlaylistCaption,
  };
  window.DownscriptAdapters.youtubeVideo = {
    platform: "youtube",
    scroll: false, // one video, nothing to lazy-load
    matches: matchesVideo,
    getPageTitle: getChannelName,
    getPageKey: getVideoPageKey,
    findVideoTiles,
    extractCaption: extractVideoCaption,
  };
})();
