// Orchestrates page detection + scroll-and-collect for whichever
// PlatformAdapter matches the current page, and streams results to the
// background service worker. See TECHNICAL_DESIGN.md §3.1.
(function () {
  // Guard against double-injection: the background worker injects this file
  // programmatically when the popup opens on a tab that predates the
  // extension load, which can race the manifest's own content_scripts entry.
  if (window.__downscriptScraperLoaded) return;
  window.__downscriptScraperLoaded = true;

  const BATCH_SIZE = 20;
  const SCROLL_MIN_PX = 600;
  const SCROLL_MAX_PX = 1200;
  const DELAY_MIN_MS = 700;
  const DELAY_MAX_MS = 1500;
  const MAX_IDLE_SCROLLS = 4;
  const HARD_CAP = 5000;

  function pickAdapter() {
    const adapters = window.DownscriptAdapters || {};
    const url = window.location.href;
    for (const key of Object.keys(adapters)) {
      if (adapters[key].matches(url)) return adapters[key];
    }
    return null;
  }

  function randBetween(min, max) {
    return Math.floor(min + Math.random() * (max - min));
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  let discoveryRunning = false;
  let cancelRequested = false;

  async function runDiscovery(adapter) {
    discoveryRunning = true;
    cancelRequested = false;

    const seen = new Map(); // id -> VideoItem
    let pending = [];
    let idleScrolls = 0;

    function flush(force) {
      if (pending.length === 0) return;
      if (!force && pending.length < BATCH_SIZE) return;
      chrome.runtime.sendMessage({
        type: "items_found",
        platform: adapter.platform,
        items: pending,
      });
      pending = [];
    }

    function collectNewTiles() {
      const tiles = adapter.findVideoTiles();
      let newCount = 0;
      for (const tile of tiles) {
        if (seen.has(tile.id)) continue;
        const item = {
          id: tile.id,
          platform: adapter.platform,
          permalink: tile.permalink || tile.el.href,
          caption: adapter.extractCaption(tile.el),
          discoveredAt: Date.now(),
        };
        seen.set(tile.id, item);
        pending.push(item);
        newCount++;
      }
      return newCount;
    }

    // Initial collection before any scrolling.
    collectNewTiles();
    flush(true);

    // Single-video adapters set scroll: false; the initial collection above
    // already found everything there is.
    while (
      adapter.scroll !== false &&
      !cancelRequested &&
      idleScrolls < MAX_IDLE_SCROLLS &&
      seen.size < HARD_CAP
    ) {
      window.scrollBy(0, randBetween(SCROLL_MIN_PX, SCROLL_MAX_PX));
      await sleep(randBetween(DELAY_MIN_MS, DELAY_MAX_MS));

      const newCount = collectNewTiles();
      flush(false);

      if (newCount === 0) {
        idleScrolls++;
      } else {
        idleScrolls = 0;
      }
    }

    flush(true);
    discoveryRunning = false;

    chrome.runtime.sendMessage({
      type: "discovery_done",
      platform: adapter.platform,
      total: seen.size,
      cancelled: cancelRequested,
    });
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "get_page_info") {
      const adapter = pickAdapter();
      if (!adapter) {
        sendResponse({ supported: false });
        return;
      }
      sendResponse({
        supported: true,
        platform: adapter.platform,
        pageTitle: adapter.getPageTitle(),
        pageKey: adapter.getPageKey ? adapter.getPageKey() : null,
      });
      return;
    }

    if (message.type === "start_discovery") {
      const adapter = pickAdapter();
      if (!adapter) {
        chrome.runtime.sendMessage({
          type: "discovery_error",
          reason: "Page is not a supported profile, reels, playlist, or video page.",
        });
        return;
      }
      if (discoveryRunning) {
        sendResponse({ ok: false, reason: "already_running" });
        return;
      }
      sendResponse({ ok: true });
      runDiscovery(adapter);
      return;
    }

    if (message.type === "cancel_discovery") {
      cancelRequested = true;
      sendResponse({ ok: true });
      return;
    }
  });
})();
