// Service worker: owns run state, the native messaging port to the
// companion process, badge/notification updates. See TECHNICAL_DESIGN.md §3.2.

const NATIVE_HOST = "com.downscript.companion";
const SETTINGS_KEY = "settings";
const RUN_PREFIX = "run:";
const LAST_RUN_KEY = "lastRunKey";

const DEFAULT_SETTINGS = {
  ytDlpPath: "/usr/local/bin/yt-dlp",
  ffmpegPath: "/usr/local/bin/ffmpeg",
  whisperCliPath: "/usr/local/bin/whisper-cli",
  whisperModelPath: "~/Models/ggml-small.bin",
  outputRoot: "~/Downloads",
  cookiesBrowser: "chrome",
};

// ---- Monetization ------------------------------------------------------
// Client-side gate: without prepaid credits, free extractions are throttled
// to one every FREE_WAIT_MS. Credits skip the wait. NOTE: this is an
// honor/soft gate — a local extension's storage and code are user-editable,
// so it deters casual over-use, it does not enforce payment cryptographically.
// Real payment verification would need a backend receiving PayPal webhooks.
const ENTITLEMENT_KEY = "entitlement";
const DEV_EMAIL = "oreneko@gmail.com"; // Chrome profile that can simulate payments
const FREE_WAIT_MS = 2 * 60 * 1000; // 2-minute pause between free extractions
const PRICE_PER_TRANSCRIPT = 0.2; // USD; "all on this page" = count * this
const PACK = { credits: 5, price: 1.0 }; // the $1 / 5-transcript pack
// PayPal.me handle for real payments, e.g. "orenknaan" for paypal.me/orenknaan.
// Empty until provided — an email address alone can't form a payment link.
const PAYPAL_ME = "";

let nativePort = null;
let currentRunKey = null; // platform:accountTitle of the run currently being driven
const freeWaitTimers = {}; // runKey -> setTimeout id for the pending free-wait

async function getEntitlement() {
  const stored = await chrome.storage.local.get(ENTITLEMENT_KEY);
  return Object.assign({ credits: 0 }, stored[ENTITLEMENT_KEY] || {});
}

async function setEntitlement(ent) {
  await chrome.storage.local.set({ [ENTITLEMENT_KEY]: ent });
}

async function addCredits(n) {
  const ent = await getEntitlement();
  ent.credits = (ent.credits || 0) + n;
  await setEntitlement(ent);
  return ent;
}

// The Chrome profile's signed-in email, used only to gate the simulated-payment
// path to the developer account. Resolves to "" if unavailable.
function getProfileEmail() {
  return new Promise((resolve) => {
    try {
      chrome.identity.getProfileUserInfo({ accountStatus: "ANY" }, (info) => {
        void chrome.runtime.lastError;
        resolve((info && info.email) || "");
      });
    } catch (e) {
      resolve("");
    }
  });
}

function runKeyFor(platform, accountTitle) {
  return `${platform}:${accountTitle}`;
}

// Adapters whose output folder is shared across pages (single YouTube videos
// are filed under their channel) supply a separate pageKey so each page
// still gets its own run.
function pageRunKey(pageInfo) {
  return runKeyFor(pageInfo.platform, pageInfo.pageKey || pageInfo.pageTitle);
}

async function getSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return Object.assign({}, DEFAULT_SETTINGS, stored[SETTINGS_KEY] || {});
}

async function getRun(key) {
  const stored = await chrome.storage.local.get(RUN_PREFIX + key);
  return stored[RUN_PREFIX + key] || null;
}

async function saveRun(run) {
  run.updatedAt = Date.now();
  await chrome.storage.local.set({
    [RUN_PREFIX + run.runKey]: run,
    [LAST_RUN_KEY]: run.runKey,
  });
  broadcastState(run);
}

function broadcastState(run) {
  chrome.runtime.sendMessage({ type: "state_update", run }, () => {
    // No popup listening is the common case; swallow the "no receiver" error.
    void chrome.runtime.lastError;
  });
  updateBadge(run);
}

function updateBadge(run) {
  if (!run || ["done", "cancelled", "paused"].includes(run.status)) {
    chrome.action.setBadgeText({ text: "" });
    return;
  }
  if (run.status === "failed") {
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#c0392b" });
    return;
  }
  const items = Object.values(run.items || {});
  const finished = items.filter((i) =>
    ["done", "skipped", "no_speech", "failed"].includes(i.status)
  ).length;
  chrome.action.setBadgeText({ text: String(finished) });
  chrome.action.setBadgeBackgroundColor({ color: "#1f9d8a" });
}

function sanitizeForFolder(name) {
  return name.replace(/[^\w.-]/g, "_").slice(0, 100) || "profile";
}

function newRun(runKey, platform, accountTitle, outputRoot) {
  return {
    runKey,
    platform,
    accountTitle,
    outputDir: `${outputRoot}/${sanitizeForFolder(accountTitle)}`,
    status: "discovering",
    items: {},
    discoveryDone: false,
    discoveryTotal: 0,
    startedAt: Date.now(),
    updatedAt: Date.now(),
  };
}

function ensureNativePort() {
  if (nativePort) return nativePort;
  nativePort = chrome.runtime.connectNative(NATIVE_HOST);
  nativePort.onMessage.addListener(handleNativeMessage);
  nativePort.onDisconnect.addListener(async () => {
    const err = chrome.runtime.lastError;
    nativePort = null;
    if (currentRunKey) {
      const run = await getRun(currentRunKey);
      // paused/cancelled disconnects are deliberate (we killed the port).
      if (run && !["done", "paused", "cancelled"].includes(run.status)) {
        run.status = "failed";
        run.failReason =
          (err && err.message) ||
          "Companion process disconnected unexpectedly.";
        await saveRun(run);
      }
    }
  });
  return nativePort;
}

async function handleNativeMessage(msg) {
  if (msg.type === "pong") {
    chrome.runtime.sendMessage({ type: "setup_check_result", result: msg }, () => {
      void chrome.runtime.lastError;
    });
    return;
  }

  if (msg.type === "item_done") {
    const run = await getRun(msg.runKey);
    if (!run) return;
    const item = run.items[msg.id];
    if (!item) return;
    item.status = msg.status; // 'done' | 'skipped' | 'no_speech' | 'failed'
    item.code = msg.code || null;
    item.reason = msg.reason || null;

    // Free-tier throttle: a gated extraction that actually hit the network
    // (done or failed, not an instant skip) forces a wait before the next one,
    // and the first successful one triggers the upgrade prompt.
    if (item.gated && msg.status !== "skipped") {
      run.freeWaitUntil = Date.now() + FREE_WAIT_MS;
      if (msg.status === "done") {
        run.freeCount = (run.freeCount || 0) + 1;
        if (run.freeCount >= 1) run.upgradePrompt = true;
      }
    }

    await maybeFinishRun(run);
    if (run.status !== "done") await pumpRun(run);
    return;
  }

  if (msg.type === "item_progress") {
    const run = await getRun(msg.runKey);
    if (!run) return;
    const item = run.items[msg.id];
    if (!item) return;
    item.phase = msg.phase;
    await saveRun(run);
    return;
  }

  if (msg.type === "debug_log_content") {
    chrome.runtime.sendMessage({ type: "debug_log_content", content: msg.content }, () => {
      void chrome.runtime.lastError;
    });
    return;
  }

  if (msg.type === "rate_limited") {
    const run = await getRun(msg.runKey);
    if (!run) return;
    run.status = "failed";
    run.failReason =
      "Platform appears to be rate-limiting requests. Try again later.";
    await saveRun(run);
    notify(
      "Downscript paused",
      `${run.accountTitle}: ${run.failReason}`
    );
  }
}

async function maybeFinishRun(run) {
  const items = Object.values(run.items);
  const finished = items.filter((i) =>
    ["done", "skipped", "no_speech", "failed"].includes(i.status)
  ).length;

  // No `items.length > 0` guard here on purpose: a page where discovery
  // finds zero videos (empty/private playlist, or an adapter selector that
  // no longer matches the page's DOM) must still resolve to "done" rather
  // than sitting in "extracting" forever at 0/0 — finished(0) >= length(0)
  // already covers that case correctly.
  if (run.discoveryDone && finished >= items.length) {
    run.status = "done";
    await saveRun(run);
    const done = items.filter((i) => i.status === "done").length;
    const skipped = items.filter((i) => i.status === "skipped").length;
    const noSpeech = items.filter((i) => i.status === "no_speech").length;
    const failed = items.filter((i) => i.status === "failed").length;
    notify(
      "Downscript finished",
      items.length === 0
        ? `${run.accountTitle}: no videos were found on this page.`
        : `${run.accountTitle}: ${done} new, ${noSpeech} no speech, ${skipped} skipped, ${failed} failed.`
    );
    currentRunKey = null;
  } else {
    await saveRun(run);
  }
}

function notify(title, message) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message,
  });
}

async function sendBatchToCompanion(run, items) {
  const settings = await getSettings();
  const port = ensureNativePort();
  port.postMessage({
    type: "extract_batch",
    runKey: run.runKey,
    platform: run.platform,
    accountTitle: run.accountTitle,
    outputDir: run.outputDir,
    settings,
    items,
  });
}

// Drives extraction one item at a time, applying the monetization gate.
// Credits (prepaid) flow with no wait; without them, each extraction is
// followed by a FREE_WAIT_MS pause. Only one item is ever in flight, so the
// wait is enforced simply by not sending the next item until it's elapsed.
async function pumpRun(run) {
  if (!run || !["discovering", "extracting"].includes(run.status)) return;

  const items = Object.values(run.items);
  if (items.some((i) => i.status === "sent")) return; // one in flight already

  const next = items.find((i) => i.status === "pending");
  if (!next) {
    await maybeFinishRun(run);
    return;
  }

  const ent = await getEntitlement();
  if ((ent.credits || 0) > 0) {
    // Prepaid: consume a credit, no wait.
    ent.credits -= 1;
    await setEntitlement(ent);
    next.gated = false;
    next.status = "sent";
    next.phase = null;
    run.freeWaitUntil = 0;
    await saveRun(run);
    await sendBatchToCompanion(run, [next]);
    return;
  }

  // Free tier: honor the pause window before sending the next item.
  const now = Date.now();
  const waitUntil = run.freeWaitUntil || 0;
  if (now < waitUntil) {
    if (freeWaitTimers[run.runKey]) clearTimeout(freeWaitTimers[run.runKey]);
    freeWaitTimers[run.runKey] = setTimeout(async () => {
      delete freeWaitTimers[run.runKey];
      const fresh = await getRun(run.runKey);
      if (fresh) await pumpRun(fresh);
    }, waitUntil - now + 250);
    await saveRun(run); // re-broadcast so the popup shows the countdown
    return;
  }

  next.gated = true;
  next.status = "sent";
  next.phase = null;
  await saveRun(run);
  await sendBatchToCompanion(run, [next]);
}

function clearFreeWaitTimer(runKey) {
  if (freeWaitTimers[runKey]) {
    clearTimeout(freeWaitTimers[runKey]);
    delete freeWaitTimers[runKey];
  }
}

async function getPageInfo(tabId) {
  try {
    return await chrome.tabs.sendMessage(tabId, { type: "get_page_info" });
  } catch (e) {
    // No listener in the tab: the page was loaded before the extension was
    // (re)loaded, or the user SPA-navigated here from a non-matching URL.
    // Inject the content scripts and retry instead of making the user reload.
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: [
          "content/adapters/tiktok.js",
          "content/adapters/facebook.js",
          "content/adapters/instagram.js",
          "content/adapters/youtube.js",
          "content/scraper.js",
        ],
      });
      return await chrome.tabs.sendMessage(tabId, { type: "get_page_info" });
    } catch (e2) {
      return null; // not a page we can inject into — genuinely unsupported
    }
  }
}

async function startRun(tabId) {
  const pageInfo = await getPageInfo(tabId);
  if (!pageInfo || !pageInfo.supported) {
    throw new Error("This page is not a supported profile, reels, playlist, or video page.");
  }

  const key = pageRunKey(pageInfo);
  let run = await getRun(key);
  const resuming = run && run.status !== "done";

  if (!run || run.status === "done") {
    const settings = await getSettings();
    run = newRun(key, pageInfo.platform, pageInfo.pageTitle, settings.outputRoot);
  } else {
    run.status = "discovering";
  }

  currentRunKey = key;
  await saveRun(run);

  if (resuming) {
    // Any item left 'sent' had its companion killed on pause/crash; revert to
    // 'pending' so the gated pump re-sends it (skip-if-exists dedups). The
    // pump then drives extraction one item at a time (TECHNICAL_DESIGN.md §7).
    for (const item of Object.values(run.items)) {
      if (item.status === "sent") item.status = "pending";
    }
    if (run.discoveryDone) {
      run.status = "extracting";
      await saveRun(run);
      await pumpRun(run);
      return run;
    }
    await saveRun(run);
    await pumpRun(run);
  }

  await chrome.tabs.sendMessage(tabId, { type: "start_discovery" });
  return run;
}

async function cancelRun(tabId) {
  if (!currentRunKey) return;
  const run = await getRun(currentRunKey);
  if (!run) return;
  try {
    await chrome.tabs.sendMessage(tabId, { type: "cancel_discovery" });
  } catch (e) {
    // Tab may already be gone — fine, we're cancelling anyway.
  }
  // Killing the port makes Chrome terminate the companion, aborting any
  // in-flight item — without this, Cancel only updated local state while the
  // companion (and whatever subprocess it was blocked on) kept running
  // server-side, which is why the button appeared to do nothing.
  if (nativePort) {
    const port = nativePort;
    nativePort = null;
    port.disconnect();
  }
  // Drop the run entirely (rather than just marking it "cancelled") so a
  // later Start treats this as a brand-new run: startRun() sees no stored
  // run, rescans the page from scratch, and re-sends every item. Already-
  // written transcripts are cheap to re-touch: pipeline.py's
  // existing_transcript() skip-if-exists check dedups them.
  clearFreeWaitTimer(run.runKey);
  await chrome.storage.local.remove(RUN_PREFIX + run.runKey);
  broadcastState(null);
  currentRunKey = null;
}

async function pauseRun(tabId) {
  if (!currentRunKey) return;
  const run = await getRun(currentRunKey);
  if (!run || !["discovering", "extracting"].includes(run.status)) return;
  try {
    await chrome.tabs.sendMessage(tabId, { type: "cancel_discovery" });
  } catch (e) {
    // Tab gone — extraction can still be paused.
  }
  // Killing the port makes Chrome terminate the companion, aborting the
  // in-flight item. Safe: resume re-sends anything not completed and the
  // companion's skip-if-exists check dedups (same path as crash recovery,
  // TECHNICAL_DESIGN.md §7).
  if (nativePort) {
    const port = nativePort;
    nativePort = null;
    port.disconnect();
  }
  for (const item of Object.values(run.items)) {
    if (item.status === "sent") item.status = "pending";
  }
  clearFreeWaitTimer(run.runKey);
  run.status = "paused";
  await saveRun(run);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message.type === "items_found") {
      if (!currentRunKey) return;
      const run = await getRun(currentRunKey);
      if (!run) return;
      for (const item of message.items) {
        if (!run.items[item.id]) {
          run.items[item.id] = Object.assign({ status: "pending" }, item);
        }
      }
      await saveRun(run);
      // Newly-discovered items stay 'pending'; the gated pump pulls them one
      // at a time so the free-tier wait can be enforced between extractions.
      await pumpRun(run);
      return;
    }

    if (message.type === "discovery_done") {
      if (!currentRunKey) return;
      const run = await getRun(currentRunKey);
      if (!run) return;
      if (message.cancelled) {
        // Pause/cancel interrupted the scroll: discovery is NOT complete, so
        // leave discoveryDone false — resume will re-run it (the scraper's
        // Set dedups already-seen tiles).
        return;
      }
      run.discoveryDone = true;
      run.discoveryTotal = message.total;
      if (run.status !== "paused") {
        run.status = "extracting";
      }
      await maybeFinishRun(run);
      if (run.status !== "done" && run.status !== "paused") await pumpRun(run);
      return;
    }

    if (message.type === "discovery_error") {
      if (!currentRunKey) return;
      const run = await getRun(currentRunKey);
      if (!run) return;
      run.status = "failed";
      run.failReason = message.reason;
      await saveRun(run);
      currentRunKey = null;
      return;
    }

    if (message.type === "popup_get_state") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      let pageInfo = null;
      if (tab && tab.id) {
        pageInfo = await getPageInfo(tab.id);
      }
      let run = null;
      if (pageInfo && pageInfo.supported) {
        run = await getRun(pageRunKey(pageInfo));
      } else if (currentRunKey) {
        run = await getRun(currentRunKey);
      }
      const ent = await getEntitlement();
      const email = await getProfileEmail();
      // Remaining transcribable items on this page (for the "pay for all" price).
      let remaining = 0;
      if (run) {
        remaining = Object.values(run.items).filter(
          (i) => !["done", "skipped", "no_speech"].includes(i.status)
        ).length;
      }
      sendResponse({
        pageInfo,
        run,
        tabId: tab && tab.id,
        billing: {
          credits: ent.credits || 0,
          devAccount: email.toLowerCase() === DEV_EMAIL,
          pricePerTranscript: PRICE_PER_TRANSCRIPT,
          pack: PACK,
          remaining,
          paypalConfigured: PAYPAL_ME.length > 0,
          freeWaitMs: FREE_WAIT_MS,
        },
      });
      return;
    }

    if (message.type === "popup_start") {
      try {
        const run = await startRun(message.tabId);
        sendResponse({ ok: true, run });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
      return;
    }

    if (message.type === "popup_cancel") {
      await cancelRun(message.tabId);
      sendResponse({ ok: true });
      return;
    }

    if (message.type === "popup_pause") {
      await pauseRun(message.tabId);
      sendResponse({ ok: true });
      return;
    }

    // Grant credits. plan: "pack" (5 for $1) or "all" (remaining on the page).
    // simulated: dev-account sandbox unlock, no real payment.
    // confirm:   honor-system unlock after the user says they paid via PayPal.
    // Otherwise: return a paypalUrl for the popup to open (no auto-verify —
    // there's no backend to confirm the payment landed).
    if (message.type === "popup_purchase") {
      const plan = message.plan === "all" ? "all" : "pack";
      const credits =
        plan === "pack" ? PACK.credits : Math.max(1, message.count || 0);
      const price =
        plan === "pack"
          ? PACK.price
          : Math.round(credits * PRICE_PER_TRANSCRIPT * 100) / 100;

      if (message.simulated) {
        const email = await getProfileEmail();
        if (email.toLowerCase() !== DEV_EMAIL) {
          sendResponse({ ok: false, error: "Simulated payment not available." });
          return;
        }
        await addCredits(credits);
      } else if (message.confirm) {
        // Honor-system: user reported completing the PayPal payment.
        await addCredits(credits);
      } else {
        // First click: hand back the PayPal URL for the popup to open.
        const url = PAYPAL_ME
          ? `https://www.paypal.com/paypalme/${PAYPAL_ME}/${price}`
          : null;
        sendResponse({ ok: true, needsPayment: true, paypalUrl: url, price, credits });
        return;
      }

      // Credits granted: clear any active free-wait and resume immediately.
      if (currentRunKey) {
        const run = await getRun(currentRunKey);
        if (run) {
          run.freeWaitUntil = 0;
          run.upgradePrompt = false;
          clearFreeWaitTimer(run.runKey);
          await saveRun(run);
          await pumpRun(run);
        }
      }
      const ent = await getEntitlement();
      sendResponse({ ok: true, credits: ent.credits });
      return;
    }

    if (message.type === "popup_open_folder") {
      const run = currentRunKey
        ? await getRun(currentRunKey)
        : await (async () => {
            const stored = await chrome.storage.local.get(LAST_RUN_KEY);
            return stored[LAST_RUN_KEY] ? getRun(stored[LAST_RUN_KEY]) : null;
          })();
      if (run && run.outputDir) {
        const port = ensureNativePort();
        port.postMessage({ type: "open_folder", path: run.outputDir });
      }
      sendResponse({ ok: true });
      return;
    }

    if (message.type === "options_check_setup") {
      const settings = await getSettings();
      const port = ensureNativePort();
      port.postMessage({ type: "ping", settings });
      sendResponse({ ok: true });
      return;
    }

    if (message.type === "options_open_debug_log") {
      const settings = await getSettings();
      const port = ensureNativePort();
      port.postMessage({ type: "open_debug_log", path: settings.outputRoot });
      sendResponse({ ok: true });
      return;
    }

    if (message.type === "options_read_debug_log") {
      const settings = await getSettings();
      const port = ensureNativePort();
      port.postMessage({ type: "read_debug_log", path: settings.outputRoot });
      sendResponse({ ok: true });
      return;
    }

    if (message.type === "popup_open_debug_log_for") {
      await chrome.storage.local.set({
        pendingDebugHighlight: { itemId: message.itemId, at: Date.now() },
      });
      chrome.runtime.openOptionsPage();
      sendResponse({ ok: true });
      return;
    }
  })().catch((e) => {
    try {
      sendResponse({ ok: false, error: e.message });
    } catch (_) {
      // Channel already closed (fire-and-forget message) — nothing to do.
    }
  });
  // Only popup/options messages expect a response; scraper events
  // (items_found, discovery_done, discovery_error) are fire-and-forget, and
  // returning true for them makes Chrome report "message channel closed"
  // errors in the page console when no response ever arrives.
  const t = message.type || "";
  return (
    t.startsWith("popup_") ||
    t === "options_check_setup" ||
    t === "options_open_debug_log" ||
    t === "options_read_debug_log"
  );
  // (popup_purchase is covered by the popup_ prefix.)
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "_execute_action") {
    // Default popup opens automatically; nothing extra needed here.
  }
});
