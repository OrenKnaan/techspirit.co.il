const SETTINGS_KEY = "settings";

const DEFAULTS = {
  ytDlpPath: "/usr/local/bin/yt-dlp",
  ffmpegPath: "/usr/local/bin/ffmpeg",
  whisperCliPath: "/usr/local/bin/whisper-cli",
  whisperModelPath: "~/Models/ggml-small.bin",
  outputRoot: "~/Downloads",
  cookiesBrowser: "chrome",
};

const FIELDS = [
  "outputRoot",
  "cookiesBrowser",
  "ytDlpPath",
  "ffmpegPath",
  "whisperCliPath",
  "whisperModelPath",
];

const statusEl = document.getElementById("status");

async function load() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  const settings = Object.assign({}, DEFAULTS, stored[SETTINGS_KEY] || {});
  for (const f of FIELDS) {
    document.getElementById(f).value = settings[f];
  }
}

async function save() {
  const settings = {};
  for (const f of FIELDS) {
    settings[f] = document.getElementById(f).value.trim();
  }
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  statusEl.textContent = "Saved.";
  statusEl.className = "ok";
}

document.getElementById("save-btn").addEventListener("click", save);

document.getElementById("check-btn").addEventListener("click", async () => {
  await save();
  statusEl.textContent = "Checking companion + binaries…";
  statusEl.className = "";
  chrome.runtime.sendMessage({ type: "options_check_setup" });
});

document.getElementById("debug-log-btn").addEventListener("click", async () => {
  await save();
  chrome.runtime.sendMessage({ type: "options_open_debug_log" });
});

const debugLogView = document.getElementById("debug-log-view");
let pendingHighlightItemId = null;

function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])
  );
}

function renderDebugLog(text, highlightItemId) {
  if (!text) {
    debugLogView.textContent = "";
    return;
  }
  const lines = text.split("\n");
  if (!highlightItemId) {
    debugLogView.textContent = text;
    return;
  }

  const headerLines = [];
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].startsWith("====")) headerLines.push(i);
  }
  let matchStart = -1;
  for (let i = headerLines.length - 1; i >= 0; i--) {
    if (lines[headerLines[i]].includes(` ${highlightItemId} `)) {
      matchStart = headerLines[i];
      break;
    }
  }
  if (matchStart === -1) {
    debugLogView.textContent = text;
    return;
  }
  const nextHeader = headerLines.find((idx) => idx > matchStart);
  const matchEnd = nextHeader !== undefined ? nextHeader : lines.length;

  const before = lines.slice(0, matchStart).join("\n");
  const match = lines.slice(matchStart, matchEnd).join("\n");
  const after = lines.slice(matchEnd).join("\n");

  debugLogView.innerHTML =
    escapeHtml(before) +
    (before ? "\n" : "") +
    `<span class="log-highlight" id="debug-log-highlight">${escapeHtml(match)}</span>` +
    (after ? "\n" : "") +
    escapeHtml(after);

  const target = document.getElementById("debug-log-highlight");
  if (target) {
    target.scrollIntoView({ block: "center" });
    setTimeout(() => target.classList.remove("log-highlight"), 3000);
  }
}

async function loadDebugLog(highlightItemId) {
  debugLogView.textContent = "Loading…";
  pendingHighlightItemId = highlightItemId || null;
  await save();
  chrome.runtime.sendMessage({ type: "options_read_debug_log" });
}

document.getElementById("debug-log-refresh-btn").addEventListener("click", () => {
  loadDebugLog(null);
});

async function checkPendingHighlight() {
  const stored = await chrome.storage.local.get("pendingDebugHighlight");
  const pending = stored.pendingDebugHighlight;
  if (!pending) return;
  await chrome.storage.local.remove("pendingDebugHighlight");
  loadDebugLog(pending.itemId);
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "debug_log_content") {
    renderDebugLog(message.content, pendingHighlightItemId);
    pendingHighlightItemId = null;
    return;
  }
  if (message.type === "setup_check_result") {
    const r = message.result;
    if (!r.ok) {
      const lines = (r.checks || [])
        .map((c) => `${c.ok ? "✓" : "✗"} ${c.name}: ${c.detail}`)
        .join("\n");
      statusEl.textContent =
        "Setup incomplete:\n" + (lines || r.error || "Unknown error.");
      statusEl.className = "bad";
    } else {
      const lines = (r.checks || [])
        .map((c) => `✓ ${c.name}: ${c.detail}`)
        .join("\n");
      statusEl.textContent = "All good!\n" + lines;
      statusEl.className = "ok";
    }
  }
});

load();
checkPendingHighlight();
